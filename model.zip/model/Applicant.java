package com.team2.model;

import java.time.LocalDate;

public class Applicant {
	
	private String name;
	private LocalDate dob;
	private String address;
	private String schoolName;
	private long phNum;
	private String email;
	private float cutOff;
	private String id;
	private String pswd;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public float getCutOff() {
		return cutOff;
	}
	public void setCutOff(float cutOff) {
		this.cutOff = cutOff;
	}
	public String getId() {
		return id;
	}
	public void setId(String applicantId) {
		this.id = applicantId;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public long getPhNum() {
		return phNum;
	}
	public void setPhNum(long phNum) {
		this.phNum = phNum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
