package com.team2.model;

import java.util.ArrayList;
import java.util.HashMap;

public class Schedule {
	
	private String type;
	//private HashMap<Integer, ArrayList<String>> scheduleList;
	
	
}
