package com.team2.model;

public class Results {
	
}
