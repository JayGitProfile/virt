package com.team2.model;

public class Attendance {
	
	private String stud_id;
	private int semester;
	private int att_percent;
	
	public String getStud_id() {
		return stud_id;
	}
	public void setStud_id(String stud_id) {
		this.stud_id = stud_id;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public int getAtt_percent() {
		return att_percent;
	}
	public void setAtt_percent(int att_percent) {
		this.att_percent = att_percent;
	}
}
